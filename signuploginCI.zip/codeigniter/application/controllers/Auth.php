<?php
class Auth extends CI_controller
{
    public function index()
    {
       
       // $this->load->view('login');
    }


public function registerdata()
{
  $this->load->model('Authmodel');
  $data = array(
    'name'=>$_POST['name'],
    'email'=>$_POST['email'],
    'password'=>$_POST['password'],
    'mobile'=>$_POST['mobile'],
);
if($data)
{
$this->Authmodel->create($data);
echo json_encode(['status'=>200,'data'=>$data,'message'=>'User successfully registered']);
}
else
{
  $data=['status'=>402,'message'=>'invalid credentials'];
  echo json_encode($data);

}
}






    public function register()
    { 
        

            $this->load->library('form_validation');

            $this->form_validation->set_rules('name','Name','min_length[5]');
            $this->form_validation->set_rules('email','Email','required');
            $this->form_validation->set_rules('password','Password','required');
            $this->form_validation->set_rules('mobile','Mobile Number','required');

            if($this->form_validation->run() == false)
              {
                 $this->load->view('register');
                 $error=$this->form_validation->error_array();
                 $loginData= array(
                     'status'=>'403',
                     'error'=> $error,
                 );
                // echo json_encode($loginData);
              }


        else{

            $this->load->model('Authmodel');
           
          
            $data = array(
                'name'=>$_POST['name'],
                'email'=>$_POST['email'],
                'password'=>$_POST['password'],
                'mobile'=>$_POST['mobile'],
            );

            $this->Authmodel->create($data);
            echo json_encode(['status'=>200,'message'=>'User successfully registered']);
           //
          //  echo json_encode($data);
           // echo("succesfully submitted");


          //  redirect(base_url().'index.php/Auth/register');
        }
             
    }


//LOGIN TABLE




    public function logindata()
    {
        $this->load->model('Authmodel');
       
      $email = $this->input->post('email');
      $password = $this->input->post('password');
      
      $userdata = $this->Authmodel->login($email,$password);
      if($userdata)
      {

        $this->session->set_userdata('email',$userdata['email']);
        $this->session->set_userdata('name',$userdata['name']);
          $data=['status'=>200,'data'=>$userdata,'message'=>'successfully logged in'];
        echo json_encode($data);
      }
      else
      {
        $data=['status'=>402,'message'=>'invalid credentials'];
         echo json_encode($data);
      }

    }
       
    public function login()
    {
        $this->load->model('Authmodel');
       
      $email = $this->input->post('email');
      $password = $this->input->post('password');
      $this->load->view('login'); 
      $userdata = $this->Authmodel->login($email,$password);
      if($userdata)
      {
        echo ('successfully logged in');
      }
      else
      {
         echo false;
      }

    }

    public function home()
    {
      
       $this->load->view('home'); 
     

    }

    public function logout()
    {
        $this->session->unset_userdata('email');
        return redirect('register');
    }
   


      

}

?>