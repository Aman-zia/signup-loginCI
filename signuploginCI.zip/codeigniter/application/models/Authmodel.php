<?php
class Authmodel extends CI_model
{
    public function create($formArray) //this func will save user record in db
    {
        $this->db->insert('signup',$formArray);
    }

    

    public function login($email, $password)
    {
        $this->db->where('email',$email);
        $this->db->where('password',$password);
        $query = $this->db->get('signup');
        return $query->row_array();
    
    }


}


?>