
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
    
    <title>LOGIN</title>
</head>
<body> 

<div class="container">





<div class="col-md-6">
<div class="card mt-5">
  <div class="card-header">
    welcome<?=$this->session->userdata('email');?>

  </div>

<form >
  <div class="card-body">


  <div class="form-group">
        <a href="<?=base_url('/Auth/logout')?>">logout</a>
   </div>
    
    
 
   <div class="form-group">
        <button class="btn btn-block btn-primary" id="logout">LOGOUT</button>
   </div>
   
   

  
   
   
  </div>
</form>


</div>
</div>
</div>
    
</body>
</html>




    
</body>
</html>