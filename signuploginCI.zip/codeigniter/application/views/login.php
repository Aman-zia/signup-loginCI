
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
    
    <title>LOGIN</title>
</head>
<body> 

<div class="container">





<div class="col-md-6">
<div class="card mt-5">
  <div class="card-header">
    LOGIN HERE
  </div>

<form >
  <div class="card-body">
    
    <p class="card-text">Fill up your details here</p>
 

    <div class="form-group">
        <label for="name">Email</label>
        <input type="email" name="email" id="email" value="" class="form-control" placeholder="Enter your Email">
        <div id="email_error_message" class="form-error"></div>
       
   </div>

   <div class="form-group">
        <label for="name">Password</label>
        <input type="password" name="password" id="password" value="" class="form-control" placeholder="Enter your Password">
        <div id="password_error_message" class="form-error"></div>
      
   </div>

  
   <br/>

   <div class="form-group">
        <button class="btn btn-block btn-primary" id="sub" onclick="return checkData()">LOGIN</button>
   </div>
   <br/>

 
   <br/>
   
   <div class="form-group">
   <span>Please signup if you are new?</span>
   <a href="register">click here</a>
   </div>
  
   
   
  </div>
</form>


</div>
</div>
</div>
    
</body>
</html>


<script>

$("input").on('keypress', function () 
{
    $(".form-error").html("");
});

$("#sub").click(function () 
{
    validate(); 
}
);

function validate() 
{
         
            var email1 = $("#email").val().trim();
            var pass = $("#password").val().trim();
         

           
            if (!validateEmail(email1)) 
            {
                $("#email_error_message").html("Please fill your email correctly including @*");
                $("#email_error_message").css("color", "red");
                return false;
            }
            else {
                $("#email_error_message").html("");
            }

            if (pass == "") 
            {
                $("#password_error_message").html("Please fill your password");
                $("#password_error_message").css("color", "red");
                return false;
            }

            if ((pass.length <= 6) || (pass.length >= 30)) {
                $("#password_error_message").html("Password length should be greater than 6*");
                $("#password_error_message").css("color", "red");
                return false;
            }

        }

        function validateEmail(email1) 
        {

const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
return re.test(String(email1).toLowerCase());
}




    function checkData(){
$.ajax({
                type: 'POST',
                url: "<?=base_url()?>Auth/logindata",
                data: 
                {
                  
                  email: $("#email").val(),
                  password: $("#password").val(),
                },
             dataType: 'json',
                success: function(data, status, xhr, message){ 
                  if(status){
                      if(data.status==200){
                        alert(data.message);
                      }else if(data.status=403){
                        console.log(Object.keys(data.error));
                    let k = Object.keys(data.error)[0];
                    $("#"+k).addClass('error-input');
                    $("#"+k).next().html(data.error[k]);
                      }
                    

    //                 Object.keys((data.error).forEach(function(key) {
    //                  console.log(key);
    //                  //var value = jsonData[key];
    // // ...
    //                 }));
                  }
               },
                error: function(jqXhr, textStatus, errorMessage) 
                {
                 alert("successfully logged in");
                }
            });



            $('#logout').click(function(event)
            {
          event.preventDefault();
//ajax<?php session_destroy();?>
          location.reload(false);
        });

        return false;

        }

</script>

    
</body>
</html>