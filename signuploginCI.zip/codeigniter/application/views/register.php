<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
    
    <title>SIGN UP</title>

    <style>

            .error-input 
            {
            border: 1px solid #ff0000 ;
            }

            .error-display 
            {
                color: #ff0000;
                text-align: left;
            }

</style>

</head>
<body> 

<div class="container">

<div>
<?php echo $this->session->userdata('email'); ?>
</div>





<div class="col-md-6">
<div class="card mt-5">
  <div class="card-header">
    SIGNUP HERE
  </div>

<form action=""  name="signupform" id="signupform" method="POST">
  <div class="card-body">
    
    <p class="card-text">Fill up your details here</p>
   <div class="form-group">
        <label for="name" >Name</label>
        <input type="text" name="name" id="name" value="" class="form-control " placeholder="Enter your name">
        <div  class="error-display "></div>
    </div>

    <div class="form-group">
        <label for="name">Email</label>
        <input type="email" name="email" id="email" value="" class="form-control" placeholder="Enter your Email">
        <div  class="error-display "></div>
   </div>

   <div class="form-group">
        <label for="name">Password</label>
        <input type="password" name="password" id="password" value="" class="form-control" placeholder="Enter your Password">
        <div  class="error-display "></div>
   </div>

   <div class="form-group">
        <label for="name">MobileNo</label>
        <input type="text" name="mobile" id="mobile" value=""class="form-control" placeholder="Enter your Mobile Number">
        <div class="error-display "></div>
   </div>
   <br/>

   <div class="form-group">
        <button type="button" class="btn btn-block btn-primary" onclick="sendData()" id="sub" value="submit" name="submit">SIGN UP</button>
   </div><br/>

   <div class="form-group">
   <span>Already have an account?</span>
   <a href="login">click here</a>
   </div>
   
   
   
  </div>
</form>

</div>
</div>
</div>



<script>
$("input").on('keyup',function(){
    $(this).removeClass('error-input');
    $(this).next().html("");
});

    function sendData(){
        if($("#name").val()==""){
            $("#name").addClass('error-input');
            $("#name").next().html("*Please fill your name!");
            return false;
        }
        if($("#email").val()==""){
            $("#email").addClass('error-input');
            $("#email").next().html("*Please fill your email including @!");
            return false;
        }
        if($("#password").val()==""){
            $("#password").addClass('error-input');
            $("#password").next().html("*Password should be of 8 digits!");
            return false;
        }
        if($("#mobile").val()==""){
            $("#mobile").addClass('error-input');
            $("#mobile").next().html("*Please fill your 10 digit mobile number!");
            return false;
            }

        
$.ajax({
                type: 'POST',
                url: "<?=base_url()?>Auth/registerdata",
                data: 
                {
                   name: $('#name').val(),
                   email: $('#email').val(),
                   password: $('#password').val(),
                   mobile: $('#mobile').val(),
                  
                   
                },
                dataType: 'json',
                success: function(data, status, xhr, message){ 
                  if(status){
                      if(data.status==200){
                        alert(data.message);
                      }else if(data.status=403){
                        console.log(Object.keys(data.error));
                    let k = Object.keys(data.error)[0];
                    $("#"+k).addClass('error-input');
                    $("#"+k).next().html(data.error[k]);
                      }
                    

    //                 Object.keys((data.error).forEach(function(key) {
    //                  console.log(key);
    //                  //var value = jsonData[key];
    // // ...
    //                 }));
                  }
               },
                error: function(jqXhr, textStatus, errorMessage) 
                {
                 alert("success");
                }
            });




        

        }
</script>

    
</body>
</html>